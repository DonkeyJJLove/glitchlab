import numpy as np
from glitchlab.core.registry import register

@register("amp_mask_mul")
def amp_mask_mul(img, ctx, mask_key: str, gain: float = 1.0, mode: str = "mul"):
    """
    Modyfikuje ctx.amplitude przy użyciu maski ctx.masks[mask_key].
    Nie zmienia samych pikseli; służy do sterowania następnymi filtrami,
    które respektują ctx.amplitude (np. wave, displace, mosh).

    Args:
        img      : (H,W,C) uint8 (zwracany bez zmian)
        ctx      : kontekst pipeline (ma .masks i .amplitude)
        mask_key : klucz maski w ctx.masks (musi istnieć)
        gain     : siła działania maski (typowo 0.5..2.0)
        mode     : "mul" (amplitude *= 1+gain*mask)
                   "set" (amplitude = gain*mask)
                   "clip" (amplitude = amplitude * mask)

    Returns:
        img (niezmieniony)
    """
    if not hasattr(ctx, "masks") or mask_key not in ctx.masks:
        raise KeyError(f"Mask '{mask_key}' not found in ctx.masks")

    mask = ctx.masks[mask_key].astype(np.float32)
    mask = (mask - mask.min()) / (mask.max() - mask.min() + 1e-8)

    h, w = img.shape[:2]
    if ctx.amplitude is None:
        ctx.amplitude = np.ones((h, w), dtype=np.float32)

    amp = ctx.amplitude.astype(np.float32)

    if mode == "mul":
        amp = amp * (1.0 + gain * mask)
    elif mode == "set":
        amp = gain * mask
    elif mode == "clip":
        amp = amp * mask
    else:
        raise ValueError("mode must be one of: 'mul', 'set', 'clip'")

    ctx.amplitude = amp
    return img
