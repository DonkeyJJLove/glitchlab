import os
import sys
import inspect
import json
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk, ImageDraw
import numpy as np

# WAŻNE: załaduj filtry, aby się ZAREJESTROWAŁY (efekt uboczny importu)
from glitchlab import filters as _filters  # noqa: F401

from glitchlab.core.pipeline import load_image, save_image, build_ctx, apply_pipeline, load_config
from glitchlab.core import registry as reg

APP_TITLE = "GlitchLab — Studio"
PANEL_BG = "#16181c"
TEXT_FG = "#e6e6e6"


def _to_rgb_uint8(a: np.ndarray) -> np.ndarray:
    a = np.asarray(a)
    if a.ndim == 2:
        a = np.stack([a, a, a], axis=-1)
    if a.ndim == 3 and a.shape[2] == 4:  # RGBA -> RGB na białym tle
        alpha = a[..., 3:4].astype(np.float32) / 255.0
        rgb = a[..., :3].astype(np.float32)
        a = (rgb * alpha + 255.0 * (1.0 - alpha)).astype(np.uint8)
    if a.dtype != np.uint8:
        if np.issubdtype(a.dtype, np.floating):
            a = np.clip(a * (255.0 if a.max() <= 1.0 else 1.0), 0, 255).astype(np.uint8)
        else:
            a = np.clip(a, 0, 255).astype(np.uint8)
    return np.ascontiguousarray(a)


def list_presets():
    base = os.path.dirname(os.path.dirname(__file__))  # .../glitchlab
    pdir = os.path.join(base, "presets")
    if not os.path.isdir(pdir):
        return []
    return sorted(os.path.splitext(fn)[0] for fn in os.listdir(pdir) if fn.lower().endswith(".yaml"))


def read_preset_yaml(preset_name: str):
    base = os.path.dirname(os.path.dirname(__file__))
    path = os.path.join(base, "presets", f"{preset_name}.yaml")
    if not os.path.exists(path):
        raise FileNotFoundError(f"Preset not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        return load_config(f.read())


def normalize_cfg(cfg, preset_name: str):
    """Akceptuje dwa formaty YAML: A) root z 'steps'; B) pojedyncza sekcja nazwana."""
    if not isinstance(cfg, dict):
        raise ValueError("Preset YAML must be a dict.")
    if ("steps" in cfg) or ("edge_mask" in cfg) or ("amplitude" in cfg):
        return cfg
    if preset_name in cfg and isinstance(cfg[preset_name], dict):
        return cfg[preset_name]
    if len(cfg) == 1 and isinstance(next(iter(cfg.values())), dict):
        return next(iter(cfg.values()))
    raise ValueError("Could not find steps/edge_mask/amplitude in preset YAML.")


def np_to_tk_img(arr: np.ndarray, max_side=1100):
    arr = _to_rgb_uint8(arr)
    pil = Image.fromarray(arr, "RGB")
    w, h = pil.size
    s = max_side / max(w, h)
    if s < 1.0:
        pil = pil.resize((int(w * s), int(h * s)), Image.BICUBIC)
    return ImageTk.PhotoImage(pil)


def to_gray(arr: np.ndarray) -> np.ndarray:
    arr = _to_rgb_uint8(arr)
    g = 0.299 * arr[..., 0] + 0.587 * arr[..., 1] + 0.114 * arr[..., 2]
    return g.astype(np.float32)


def preview_histogram(arr: np.ndarray, size=(320, 160)) -> Image.Image:
    g = to_gray(arr)
    hist, _ = np.histogram(g, bins=256, range=(0, 255))
    hist = hist / (hist.max() + 1e-8)
    w, h = size
    im = Image.new("RGB", size, (20, 22, 26))
    dr = ImageDraw.Draw(im)
    for i, v in enumerate(hist):
        x0 = int(i / 256 * w)
        x1 = int((i + 1) / 256 * w)
        y1 = h - 1
        y0 = int(h - v * (h - 6))  # mały margines
        dr.rectangle([x0, y0, x1, y1], fill=(110, 220, 255))
    dr.text((6, 6), "Histogram", fill=(230, 230, 230))
    return im


def preview_edges(arr: np.ndarray, size=(320, 160)) -> Image.Image:
    g = to_gray(arr) / 255.0
    gx = np.zeros_like(g)
    gy = np.zeros_like(g)
    gx[:, 1:] = np.abs(g[:, 1:] - g[:, :-1])
    gy[1:, :] = np.abs(g[1:, :] - g[:-1, :])
    edges = np.clip((gx + gy) * 1.2, 0, 1)
    ed = (edges * 255).astype(np.uint8)
    im = Image.fromarray(ed, "L").convert("RGB").resize(size, Image.BICUBIC)
    dr = ImageDraw.Draw(im)
    dr.text((6, 6), "Edges (|∇|)", fill=(240, 240, 240))
    return im


def preview_fft(arr: np.ndarray, size=(320, 160)) -> Image.Image:
    g = to_gray(arr)
    f = np.fft.fft2(g)
    fs = np.fft.fftshift(f)
    mag = np.log1p(np.abs(fs))
    mag = (mag - mag.min()) / (mag.max() - mag.min() + 1e-8)
    im = Image.fromarray((mag * 255).astype(np.uint8), "L").convert("RGB").resize(size, Image.BICUBIC)
    dr = ImageDraw.Draw(im)
    dr.text((6, 6), "FFT |F|", fill=(240, 240, 240))
    return im


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        # layout: górny obraz (2/3), dolny panel (1/3)
        self.rowconfigure(0, weight=2)
        self.rowconfigure(1, weight=1)
        self.columnconfigure(0, weight=1)

        # STANY
        self.arr_in = None          # wejście
        self.arr_view = None        # to, co aktualnie na podglądzie
        self.result = None          # wynik pipeline
        self.current_steps = []     # edytowalna lista kroków (dicty z name/params)
        self.ctx = None

        # === GÓRNY OBSZAR: podgląd ===
        top = tk.Frame(self, bg=PANEL_BG)
        top.grid(row=0, column=0, sticky="nsew")
        top.rowconfigure(0, weight=0)
        top.rowconfigure(1, weight=1)
        top.columnconfigure(0, weight=1)

        tb = tk.Frame(top, bg=PANEL_BG)
        tb.grid(row=0, column=0, sticky="ew", padx=8, pady=6)
        for i in range(1, 8):
            tb.columnconfigure(i, weight=0)
        tb.columnconfigure(0, weight=1)

        ttk.Button(tb, text="Otwórz obraz…", command=self.on_open).grid(row=0, column=0, sticky="w")

        ttk.Label(tb, text="Preset:").grid(row=0, column=1, padx=(12, 4))
        self.preset_var = tk.StringVar(self)
        presets = list_presets() or ["default"]
        self.preset_var.set(presets[0])
        self.cmb_presets = ttk.Combobox(tb, values=presets, textvariable=self.preset_var, state="readonly", width=26)
        self.cmb_presets.grid(row=0, column=2)

        ttk.Label(tb, text="Seed:").grid(row=0, column=3, padx=(12, 4))
        self.seed_var = tk.IntVar(self, 7)
        ttk.Entry(tb, textvariable=self.seed_var, width=8).grid(row=0, column=4)

        ttk.Button(tb, text="Załaduj preset", command=self.load_preset_into_steps).grid(row=0, column=5, padx=(12, 0))
        ttk.Button(tb, text="Uruchom pipeline", command=self.run_pipeline).grid(row=0, column=6, padx=(6, 0))
        ttk.Button(tb, text="Zapisz wynik…", command=self.on_save).grid(row=0, column=7, padx=(6, 0))

        # obraz
        self.canvas = tk.Label(top, text="(brak obrazu)", bg="#0b0c0f", fg=TEXT_FG)
        self.canvas.grid(row=1, column=0, sticky="nsew")

        # === DOLNY PANEL: 3 kolumny ===
        bottom = tk.Frame(self, bg=PANEL_BG)
        bottom.grid(row=1, column=0, sticky="nsew")
        for i in range(3):
            bottom.columnconfigure(i, weight=1)
        bottom.rowconfigure(0, weight=1)

        # LEWA: Pipeline/Presety
        self.col_left = tk.LabelFrame(bottom, text="Pipeline & Presets", bg=PANEL_BG, fg=TEXT_FG)
        self.col_left.grid(row=0, column=0, sticky="nsew", padx=6, pady=6)
        for r in range(6):
            self.col_left.rowconfigure(r, weight=0)
        self.col_left.rowconfigure(3, weight=1)  # lista rośnie
        self.col_left.columnconfigure(0, weight=1)
        self.col_left.columnconfigure(1, weight=0)

        self.lb_steps = tk.Listbox(self.col_left, height=8)
        self.lb_steps.grid(row=0, column=0, rowspan=4, sticky="nsew", padx=(6, 3), pady=(6, 6))
        btns = tk.Frame(self.col_left, bg=PANEL_BG)
        btns.grid(row=0, column=1, rowspan=4, sticky="ns", pady=6)
        ttk.Button(btns, text="↑", width=3, command=self.step_up).pack(pady=2)
        ttk.Button(btns, text="↓", width=3, command=self.step_down).pack(pady=2)
        ttk.Button(btns, text="✕", width=3, command=self.step_del).pack(pady=2)
        ttk.Button(btns, text="+", width=3, command=self.add_selected_filter_to_steps).pack(pady=2)

        tk.Label(self.col_left, text="Zapisz preset jako…", bg=PANEL_BG, fg=TEXT_FG).grid(row=4, column=0, sticky="w", padx=6)
        self.save_name_var = tk.StringVar(self, "my_preset")
        ttk.Entry(self.col_left, textvariable=self.save_name_var).grid(row=5, column=0, sticky="ew", padx=6)
        ttk.Button(self.col_left, text="Zapisz", command=self.save_steps_as_preset).grid(row=5, column=1, sticky="e", padx=6)

        # ŚRODEK: Analiza (Histogram, Edges, FFT)
        self.col_mid = tk.LabelFrame(bottom, text="Analiza", bg=PANEL_BG, fg=TEXT_FG)
        self.col_mid.grid(row=0, column=1, sticky="nsew", padx=6, pady=6)
        for c in range(3):
            self.col_mid.columnconfigure(c, weight=1)
        self.col_mid.rowconfigure(0, weight=1)

        self.prev_hist = tk.Label(self.col_mid, bg="#0b0c0f")
        self.prev_hist.grid(row=0, column=0, sticky="nsew", padx=6, pady=6)
        self.prev_edges = tk.Label(self.col_mid, bg="#0b0c0f")
        self.prev_edges.grid(row=0, column=1, sticky="nsew", padx=6, pady=6)
        self.prev_fft = tk.Label(self.col_mid, bg="#0b0c0f")
        self.prev_fft.grid(row=0, column=2, sticky="nsew", padx=6, pady=6)

        # PRAWA: Filtry (pełny katalog + dynamiczne parametry)
        self.col_right = tk.LabelFrame(bottom, text="Filtry & Parametry", bg=PANEL_BG, fg=TEXT_FG)
        self.col_right.grid(row=0, column=2, sticky="nsew", padx=6, pady=6)
        for r in range(6):
            self.col_right.rowconfigure(r, weight=0)
        self.col_right.rowconfigure(4, weight=1)
        self.col_right.columnconfigure(0, weight=1)

        tk.Label(self.col_right, text="Wybierz filtr:", bg=PANEL_BG, fg=TEXT_FG).grid(row=0, column=0, sticky="w", padx=6, pady=(6, 2))
        self.filters_list = sorted(list(reg.registry.keys()))
        self.filter_var = tk.StringVar(self, self.filters_list[0] if self.filters_list else "")
        self.cmb_filters = ttk.Combobox(self.col_right, values=self.filters_list, textvariable=self.filter_var, state="readonly")
        self.cmb_filters.grid(row=1, column=0, sticky="ew", padx=6)
        self.cmb_filters.bind("<<ComboboxSelected>>", lambda e: self.build_param_form())

        # dynamiczne parametry
        self.params_frame = tk.Frame(self.col_right, bg=PANEL_BG)
        self.params_frame.grid(row=2, column=0, sticky="nsew", padx=6, pady=6)
        self.param_vars = {}  # nazwa -> tk.Variable

        # akcje filtra
        act = tk.Frame(self.col_right, bg=PANEL_BG)
        act.grid(row=3, column=0, sticky="ew", padx=6, pady=(0, 6))
        ttk.Button(act, text="Apply single filter", command=self.apply_single_filter).pack(side=tk.LEFT)
        ttk.Button(act, text="Dodaj do pipeline", command=self.add_selected_filter_to_steps).pack(side=tk.LEFT, padx=(6, 0))

        # maski i kontekst
        ctxb = tk.LabelFrame(self.col_right, text="Maski & Kontekst", bg=PANEL_BG, fg=TEXT_FG)
        ctxb.grid(row=4, column=0, sticky="nsew", padx=6, pady=6)
        ttk.Button(ctxb, text="Załaduj maskę…", command=self.load_mask).pack(side=tk.LEFT, padx=4, pady=6)
        ttk.Button(ctxb, text="Reset do wejścia", command=self.reset_to_input).pack(side=tk.LEFT, padx=4, pady=6)

        # start
        self.build_param_form()
        self.status("Gotowy")

    # === UTIL ===
    def status(self, txt: str):
        self.title(f"{APP_TITLE} — {txt}")

    def show_image(self, arr):
        self.arr_view = _to_rgb_uint8(arr)
        tkimg = np_to_tk_img(self.arr_view)
        self.canvas.configure(image=tkimg, text="")
        self.canvas.image = tkimg
        self.update_analysis_previews()

    def update_analysis_previews(self):
        if self.arr_view is None:
            return
        ph = ImageTk.PhotoImage(preview_histogram(self.arr_view))
        pe = ImageTk.PhotoImage(preview_edges(self.arr_view))
        pf = ImageTk.PhotoImage(preview_fft(self.arr_view))
        self.prev_hist.configure(image=ph); self.prev_hist.image = ph
        self.prev_edges.configure(image=pe); self.prev_edges.image = pe
        self.prev_fft.configure(image=pf); self.prev_fft.image = pf

    def reset_to_input(self):
        if self.arr_in is not None:
            self.show_image(self.arr_in)

    # === IO ===
    def on_open(self):
        path = filedialog.askopenfilename(
            title="Wybierz obraz",
            filetypes=[("Images", "*.png;*.jpg;*.jpeg;*.bmp;*.webp"), ("All", "*.*")]
        )
        if not path:
            return
        try:
            a = load_image(path)
            a = _to_rgb_uint8(a)
            self.arr_in = a
            self.ctx = build_ctx(self.arr_in, seed=int(self.seed_var.get()), cfg={})
            self.current_steps = []  # nowa sesja pipeline
            self.lb_steps.delete(0, tk.END)
            self.show_image(self.arr_in)
            self.status(f"Wczytano: {os.path.basename(path)}  |  {a.shape[1]}×{a.shape[0]}")
        except Exception as e:
            messagebox.showerror("Błąd", str(e))

    def on_save(self):
        if self.arr_view is None:
            messagebox.showinfo("Info", "Brak obrazu do zapisania.")
            return
        out_path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG", "*.png")])
        if out_path:
            try:
                save_image(_to_rgb_uint8(self.arr_view), out_path)
                self.status(f"Zapisano: {os.path.basename(out_path)}")
            except Exception as e:
                messagebox.showerror("Błąd", str(e))

    # === PRESETY/PIPELINE ===
    def load_preset_into_steps(self):
        if self.arr_in is None:
            messagebox.showwarning("Uwaga", "Najpierw wczytaj obraz.")
            return
        try:
            name = self.preset_var.get()
            raw = read_preset_yaml(name)
            cfg = normalize_cfg(raw, name)
            steps = cfg.get("steps", [])
            self.current_steps = [dict(s) for s in steps]
            self.refresh_steps_listbox()
            self.ctx = build_ctx(self.arr_in, seed=int(self.seed_var.get()), cfg=cfg)
            self.status(f"Preset '{name}' załadowany. Kroki: {len(self.current_steps)}")
        except Exception as e:
            messagebox.showerror("Błąd", str(e))

    def refresh_steps_listbox(self):
        self.lb_steps.delete(0, tk.END)
        for s in self.current_steps:
            nm = s.get("name", "?")
            prm = s.get("params", {})
            self.lb_steps.insert(tk.END, f"{nm} {json.dumps(prm, ensure_ascii=False)}")

    def run_pipeline(self):
        if self.arr_in is None:
            messagebox.showwarning("Uwaga", "Najpierw wczytaj obraz.")
            return
        try:
            cfg = {"steps": self.current_steps}
            self.ctx = build_ctx(self.arr_in, seed=int(self.seed_var.get()), cfg=cfg)
            out = apply_pipeline(self.arr_in.copy(), self.ctx, self.current_steps)
            self.result = _to_rgb_uint8(out)
            self.show_image(self.result)
            self.status(f"Pipeline OK | kroki: {len(self.current_steps)}")
        except Exception as e:
            messagebox.showerror("Błąd", str(e))

    def save_steps_as_preset(self):
        name = self.save_name_var.get().strip() or "my_preset"
        base = os.path.dirname(os.path.dirname(__file__))
        p = os.path.join(base, "presets", f"{name}.yaml")
        try:
            os.makedirs(os.path.dirname(p), exist_ok=True)
            # zapis w formacie B (sekcja nazwana)
            import yaml
            data = {name: {"steps": self.current_steps}}
            with open(p, "w", encoding="utf-8") as f:
                yaml.safe_dump(data, f, allow_unicode=True, sort_keys=False)
            messagebox.showinfo("OK", f"Zapisano preset: {p}")
        except Exception as e:
            messagebox.showerror("Błąd", str(e))

    def step_up(self):
        i = self.lb_steps.curselection()
        if not i:
            return
        idx = i[0]
        if idx == 0:
            return
        self.current_steps[idx - 1], self.current_steps[idx] = self.current_steps[idx], self.current_steps[idx - 1]
        self.refresh_steps_listbox()
        self.lb_steps.selection_set(idx - 1)

    def step_down(self):
        i = self.lb_steps.curselection()
        if not i:
            return
        idx = i[0]
        if idx >= len(self.current_steps) - 1:
            return
        self.current_steps[idx + 1], self.current_steps[idx] = self.current_steps[idx], self.current_steps[idx + 1]
        self.refresh_steps_listbox()
        self.lb_steps.selection_set(idx + 1)

    def step_del(self):
        i = self.lb_steps.curselection()
        if not i:
            return
        idx = i[0]
        del self.current_steps[idx]
        self.refresh_steps_listbox()

    # === PRZEGLĄDARKA FILTRÓW ===
    def build_param_form(self):
        for w in self.params_frame.winfo_children():
            w.destroy()
        self.param_vars.clear()
        fname = self.filter_var.get()
        if not fname:
            return
        try:
            fn = reg.get(fname)
        except KeyError:
            tk.Label(self.params_frame, text=f"Brak filtra: {fname}", bg=PANEL_BG, fg="orange").pack(anchor="w")
            return

        sig = inspect.signature(fn)
        row = 0
        tk.Label(self.params_frame, text=f"{fname}(", bg=PANEL_BG, fg=TEXT_FG, font=("TkDefaultFont", 10, "bold")).grid(row=row, column=0, sticky="w")
        row += 1

        for p in list(sig.parameters.values())[2:]:  # pomiń img, ctx
            name = p.name
            default = p.default if p.default is not inspect._empty else ""
            var = None
            # typowanie po default
            if isinstance(default, bool):
                var = tk.BooleanVar(self.params_frame, value=bool(default))
                ttk.Checkbutton(self.params_frame, text=name, variable=var).grid(row=row, column=0, sticky="w", padx=2, pady=1)
                row += 1
            elif isinstance(default, int):
                var = tk.IntVar(self.params_frame, value=int(default))
                self._param_row(name, var, row); row += 1
            elif isinstance(default, float):
                var = tk.DoubleVar(self.params_frame, value=float(default))
                self._param_row(name, var, row); row += 1
            else:
                # string / inne
                var = tk.StringVar(self.params_frame, value=str(default))
                self._param_row(name, var, row); row += 1
            self.param_vars[name] = var

        tk.Label(self.params_frame, text=")", bg=PANEL_BG, fg=TEXT_FG).grid(row=row, column=0, sticky="w")

    def _param_row(self, name, var, row):
        fr = tk.Frame(self.params_frame, bg=PANEL_BG)
        fr.grid(row=row, column=0, sticky="ew", padx=2, pady=1)
        tk.Label(fr, text=f"{name}:", bg=PANEL_BG, fg=TEXT_FG, width=16, anchor="w").pack(side=tk.LEFT)
        ttk.Entry(fr, textvariable=var, width=18).pack(side=tk.LEFT, fill="x", expand=True)

    def params_from_form(self):
        out = {}
        for k, v in self.param_vars.items():
            val = v.get()
            # prosta próba JSON (żeby wpisać listy/obiekty): ["x",1], {"a":2}
            if isinstance(val, str):
                s = val.strip()
                if s.startswith("{") or s.startswith("[") or s.startswith('"'):
                    try:
                        val = json.loads(s)
                    except Exception:
                        pass
            out[k] = val
        return out

    def apply_single_filter(self):
        if self.arr_view is None:
            messagebox.showwarning("Uwaga", "Najpierw wczytaj obraz.")
            return
        fname = self.filter_var.get()
        fn = reg.get(fname)
        params = self.params_from_form()
        try:
            # ctx zachowujemy (maski, amplitude itp.)
            if self.ctx is None:
                self.ctx = build_ctx(self.arr_view, seed=int(self.seed_var.get()), cfg={})
            out = fn(self.arr_view.copy(), self.ctx, **params)
            self.show_image(out)
            self.status(f"{fname} OK")
        except Exception as e:
            messagebox.showerror("Błąd filtra", f"{fname}: {e}")

    def add_selected_filter_to_steps(self):
        fname = self.filter_var.get()
        params = self.params_from_form()
        self.current_steps.append({"name": fname, "params": params})
        self.refresh_steps_listbox()

    # === MASKI/KONTEXT ===
    def load_mask(self):
        if self.ctx is None:
            if self.arr_in is None:
                messagebox.showwarning("Uwaga", "Najpierw wczytaj obraz.")
                return
            self.ctx = build_ctx(self.arr_in, seed=int(self.seed_var.get()), cfg={})

        path = filedialog.askopenfilename(
            title="Wybierz obraz maski (L lub RGB)",
            filetypes=[("Images", "*.png;*.jpg;*.jpeg;*.bmp;*.webp"), ("All", "*.*")]
        )
        if not path:
            return
        try:
            m = load_image(path)  # (H,W,C)
            if m.ndim == 3:
                m = 0.299 * m[...,0] + 0.587 * m[...,1] + 0.114 * m[...,2]
            m = (m - m.min()) / (m.max() - m.min() + 1e-8)
            key = os.path.splitext(os.path.basename(path))[0]
            self.ctx.masks[key] = m.astype(np.float32)
            messagebox.showinfo("OK", f"Maska '{key}' załadowana do ctx.masks")
        except Exception as e:
            messagebox.showerror("Błąd", str(e))


if __name__ == "__main__":
    print(APP_TITLE, "| Python", sys.version)
    app = App()
    app.mainloop()
